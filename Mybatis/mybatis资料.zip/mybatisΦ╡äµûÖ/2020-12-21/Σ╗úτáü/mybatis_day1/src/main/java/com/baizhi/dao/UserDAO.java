package com.baizhi.dao;

import com.baizhi.entity.User;

public interface UserDAO {

    //保存用户
    int save(User user);


}
