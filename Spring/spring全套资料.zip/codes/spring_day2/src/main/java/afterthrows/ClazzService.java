package afterthrows;

public interface ClazzService {

    void  save(String name);

    String find(String name);
}
