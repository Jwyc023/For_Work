package aop;

public interface EmpService {

    void save(String name);

    String find(String name);
}
