package com.baizhi.service;

public interface BService {
    void update();
    String find();
}
