package com.baizhi.service;

public interface AService {
    void save();
    String find();
}
