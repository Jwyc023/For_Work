package di;

public interface DeptDAO {
    void save(String name);
}
