package di;

public interface DeptService {

    void save(String  name);
}
