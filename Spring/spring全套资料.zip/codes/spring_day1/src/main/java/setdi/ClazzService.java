package setdi;

public interface ClazzService {
    void save(String name);
}
