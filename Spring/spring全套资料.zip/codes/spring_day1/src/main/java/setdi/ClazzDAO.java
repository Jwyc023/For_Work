package setdi;

public interface ClazzDAO {
    void save(String name);
}
