package scope;

public interface TagDAO {
    void save(String name);
}
