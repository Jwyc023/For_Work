package init;

public interface CityDAO {

    void delete(String id);
}
