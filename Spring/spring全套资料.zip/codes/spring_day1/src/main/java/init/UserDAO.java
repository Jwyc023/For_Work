package init;

public interface UserDAO {

    void save(String name);
}
