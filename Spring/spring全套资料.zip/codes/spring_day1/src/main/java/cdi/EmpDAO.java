package cdi;

public interface EmpDAO {
    void save(String name);
}
