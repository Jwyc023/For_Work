package adi;

public interface StudentService {
    void save(String name);
}
