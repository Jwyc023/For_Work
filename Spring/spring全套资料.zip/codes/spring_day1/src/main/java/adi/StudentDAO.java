package adi;

public interface StudentDAO {
    void save(String name);
}
