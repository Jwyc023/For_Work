package com.baizhi.dao;

public interface UserDAO {

    void save(String name);
}
