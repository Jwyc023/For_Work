package com.baizhi.service;

public interface UserService {

    void save(String name);

    void find();
}
